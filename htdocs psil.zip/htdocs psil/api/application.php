<?php

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://script.google.com/macros/s/AKfycbyZlXaxgbxYjXO8-ch6OHs1hkFcLq1s_EbSX2ZFT5FSYZTL06dY5DONNAYOzKe03GDmig/exec?name=".urlencode($_GET['name'])."&birthday=".urlencode($_GET['birthday'])."&email=".urlencode($_GET['email'])."&contact=".urlencode($_GET['contact'])."&gender=".urlencode($_GET['gender'])."&domain=".urlencode($_GET['domain'])."&college=".urlencode($_GET['college'])."&qualification=".urlencode($_GET['qualification'])."&address=".urlencode($_GET['address'])."&type=application",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
));

$response = curl_exec($curl);

curl_close($curl);

header("Location: /psil/login.html");
die();

?>